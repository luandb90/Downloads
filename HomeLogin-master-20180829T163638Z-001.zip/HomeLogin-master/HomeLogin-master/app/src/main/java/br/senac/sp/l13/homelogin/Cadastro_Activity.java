package br.senac.sp.l13.homelogin;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Cadastro_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cadastramento_activity);
    }
}
