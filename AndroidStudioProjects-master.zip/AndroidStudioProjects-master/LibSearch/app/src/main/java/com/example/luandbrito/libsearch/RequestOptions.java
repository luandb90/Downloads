package com.example.luandbrito.libsearch;

/**
 * Created by luan.dbrito on 21/08/2018.
 */

class RequestOptions {
    public void centerCrop() {
    }
}
