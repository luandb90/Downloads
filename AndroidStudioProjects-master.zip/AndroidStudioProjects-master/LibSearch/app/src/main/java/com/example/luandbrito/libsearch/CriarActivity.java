package com.example.luandbrito.libsearch;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class CriarActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.criar_layout);
    }
}
