package com.example.luandbrito.libsearch;

import android.app.Activity;

/**
 * Created by luan.dbrito on 10/08/2018.
 */

public class SplashActivity extends Activity {
}
