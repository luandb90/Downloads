package com.example.luandbrito.projetorecycleview;


public class Listaitem {

    private String titulo;
    private String descricao;


    public String getTitulo() {
        return titulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public Listaitem(String titulo, String descricao) {
        this.titulo = titulo;
        this.descricao = descricao;


    }
}
